var express = require("express");
var nodemon = require("nodemon");
var app = express();
var path = require("path");
var cors = require("cors");
var fs = require("fs");
app.use(cors());

var http = require("http").Server(app);
const PORT = 3000;

var bodyParser = require("body-parser");
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, "../dist/assignmentp1")));

// listen.js
const listen = require("../server/routes/listen.js");
listen.listen(http, PORT);

// routes
require("./routes/auth-routes.js")(app, path);
require("./routes/group-routes.js")(app, path);
